package Problem3_StatePattern;

public interface State 
{
	public void execute(Robot robot);
}
