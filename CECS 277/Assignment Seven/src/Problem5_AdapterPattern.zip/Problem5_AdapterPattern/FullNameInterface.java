package Problem5_AdapterPattern;

public interface FullNameInterface 
{
	public void setFirstName(String firstName);
	public void setLastName(String lastName);
	public String getFirstName();
	public String getLastName();
}
