package Problem5_AdapterPattern;

public interface NameInterface 
{
	public void setName(String n);
	public String getName();
}
