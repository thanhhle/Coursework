package Problem1_VisitorPattern;

public interface Visitor 
{
	public abstract double visit(Product product);
}
