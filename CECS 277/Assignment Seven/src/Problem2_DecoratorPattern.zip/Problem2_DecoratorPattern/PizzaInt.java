package Problem2_DecoratorPattern;

public interface PizzaInt 
{
	public void makePizza();
}
