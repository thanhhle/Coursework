package Problem4_CommandPattern;

public interface Order 
{
	public void execute();
}
